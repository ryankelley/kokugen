<?

// ** MySQL settings ** //
define('DB_NAME', 'yourDB');    // The name of the database
define('DB_USER', 'yourUser');     // Your MySQL username
define('DB_PASSWORD', 'yourPassword'); // ...and password
define('DB_HOST', 'yourHost');    // 99% chance you won't need to change this value

?>